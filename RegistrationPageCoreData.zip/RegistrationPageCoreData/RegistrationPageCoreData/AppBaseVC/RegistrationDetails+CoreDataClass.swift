//
//  RegistrationDetails+CoreDataClass.swift
//  RegistrationPageCoreData
//
//  Created by MacMiniOld on 19/11/18.
//  Copyright © 2018 Xongolab. All rights reserved.
//
//

import Foundation
import CoreData

@objc(RegistrationDetails)
public class RegistrationDetails: NSManagedObject {

}
